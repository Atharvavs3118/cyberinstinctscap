import React, { useState } from 'react';
import {
  Shield,
  Lock,
  User,
  Mail,
  KeyRound,
  Eye,
  EyeOff,
  CheckCircle2,
  Building2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  UserCheck,
  Fingerprint,
  Radio,
  FileCheck,
  AlertCircle,
  HelpCircle,
  ExternalLink,
  Scale,
  LogIn,
} from 'lucide-react';
import { UserProfile } from '../types';
import { loginUser, registerUser, DEMO_USERS } from '../services/firebase/auth';

interface LoginPageProps {
  currentUser?: UserProfile;
  onLoginSuccess: (user: UserProfile) => void;
  onLogout: () => void;
  onNavigateToTab: (tab: any) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  currentUser,
  onLoginSuccess,
  onLogout,
  onNavigateToTab,
  onShowToast,
}) => {
  const [activeTab, setActiveTab] = useState<'signin' | 'register'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState('Lead Cybersecurity Analyst');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [forgotModalOpen, setForgotModalOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState(false);

  // Handle standard login
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await loginUser({ username: email, password });
      onLoginSuccess(res.user);
      onShowToast(`Authentication successful. Welcome, ${res.user.fullName}!`, 'success');
      onNavigateToTab('dashboard');
    } catch (err: any) {
      const msg = err?.message || 'Authentication failed. Please verify credentials.';
      setError(msg);
      onShowToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  // Handle registration
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const username = email.split('@')[0] || 'analyst';
      const user = await registerUser({
        fullName,
        username,
        email,
        password,
      });
      onLoginSuccess(user);
      onShowToast(`Account created for ${user.fullName} with role ${role}!`, 'success');
      onNavigateToTab('dashboard');
    } catch (err: any) {
      const msg = err?.message || 'Registration failed. Check password requirements.';
      setError(msg);
      onShowToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  // Fast Persona Switcher
  const handleSelectPreset = async (presetUser: (typeof DEMO_USERS)[0]) => {
    setError(null);
    setLoading(true);
    try {
      const res = await loginUser({
        username: presetUser.email,
        password: presetUser.password,
      });
      onLoginSuccess(res.user);
      onShowToast(`Authenticated as ${res.user.fullName} (${res.user.role})`, 'success');
      onNavigateToTab('dashboard');
    } catch (err: any) {
      onShowToast('Could not load preset persona: ' + (err?.message || 'Error'), 'error');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordReset = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotSuccess(true);
    setTimeout(() => {
      setForgotModalOpen(false);
      setForgotSuccess(false);
      onShowToast(`Password recovery link dispatched to ${forgotEmail}`, 'info');
    }, 1500);
  };

  return (
    <div className="max-w-5xl mx-auto py-6 px-4 space-y-6">
      {/* Active Session Notification if already authenticated */}
      {currentUser && (
        <div className="bg-emerald-50 border border-emerald-200/80 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xs">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-base shadow-sm">
              {currentUser.avatar || currentUser.fullName.substring(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-emerald-950">
                  {currentUser.fullName}
                </span>
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-md font-mono">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  AUTHENTICATED
                </span>
              </div>
              <p className="text-xs text-emerald-800">
                {currentUser.role} · <span className="font-mono">{currentUser.email}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <button
              onClick={() => onNavigateToTab('dashboard')}
              className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>Access SOC Dashboard</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onLogout}
              className="px-3.5 py-2 rounded-xl bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-semibold transition-colors cursor-pointer"
            >
              Sign Out
            </button>
          </div>
        </div>
      )}

      {/* Official Government Justice & Law Enforcement Portals Gateway */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 text-white shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-blue-700 flex items-center justify-center text-white shrink-0 shadow-xs">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-blue-900 text-blue-100 border border-blue-700">
                GOVERNMENT OF INDIA • MHA & NIC
              </span>
              <span className="text-xs text-slate-300 hidden sm:inline">National Crime Records Bureau & Supreme Court e-Committee</span>
            </div>
            <h3 className="text-base font-bold text-white mt-1">
              CCTNS & ICJS Official Portal Gateway
            </h3>
            <p className="text-xs text-slate-300 max-w-xl mt-0.5">
              Integrated with the Crime and Criminal Tracking Network & Systems (16,500+ Police Stations) and the Inter-Operable Criminal Justice System (ICJS Phase-II).
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <a
            href="https://digitalpolice.gov.in"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-xs active:scale-95"
            title="Open CCTNS Citizen & Law Enforcement Portal (digitalpolice.gov.in)"
          >
            <Building2 className="w-4 h-4 text-white" />
            <span>CCTNS Portal</span>
            <ExternalLink className="w-3.5 h-3.5 text-white/80" />
          </a>

          <a
            href="https://icjs.gov.in"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-xs active:scale-95"
            title="Open Inter-Operable Criminal Justice System (icjs.gov.in)"
          >
            <Scale className="w-4 h-4 text-white" />
            <span>ICJS Gateway</span>
            <ExternalLink className="w-3.5 h-3.5 text-white/80" />
          </a>
        </div>
      </div>

      {/* Main Authentication Card */}
      <div className="bg-white rounded-3xl border border-slate-300 shadow-md overflow-hidden grid grid-cols-1 lg:grid-cols-12">
        {/* Left Column (5 cols): Security Operations Branding & Persona Quick-Select */}
        <div className="lg:col-span-5 bg-slate-900 p-6 sm:p-8 text-white flex flex-col justify-between space-y-6 border-r border-slate-800">
          <div className="space-y-5">
            {/* Header Brand */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-700 flex items-center justify-center text-white font-bold shadow-xs">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white tracking-tight leading-none">
                  CyberInstincts
                </h2>
                <p className="text-xs text-slate-300 font-semibold mt-1">
                  Incident Response & Evidence Control
                </p>
              </div>
            </div>

            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                Security Operations Authentication
              </h3>
              <p className="text-xs text-slate-200 mt-1.5 leading-relaxed">
                Sign in to access real-time incident telemetry, MiniVault SHA-256 cryptographic proof custody, and statutory regulatory filings.
              </p>
            </div>

            {/* Quick 1-Click Persona Selector */}
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-semibold">Select Authorized Officer Profile:</span>
                <span className="text-xs text-blue-300 font-bold">1-Click Fill</span>
              </div>

              <div className="grid grid-cols-1 gap-2">
                {DEMO_USERS.map((persona) => (
                  <button
                    key={persona.id}
                    onClick={() => handleSelectPreset(persona)}
                    disabled={loading}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/90 border border-slate-700 hover:border-slate-500 transition-all text-left group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-blue-700 text-white flex items-center justify-center text-xs font-bold shrink-0">
                        {persona.avatar}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-white truncate">
                          {persona.fullName}
                        </p>
                        <p className="text-[11px] text-slate-300 truncate">
                          {persona.role}
                        </p>
                      </div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-white group-hover:translate-x-0.5 transition-all shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Security Seals */}
          <div className="pt-4 border-t border-slate-800 space-y-2 text-xs text-slate-300">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Encrypted Authentication & Audit Active</span>
            </div>
            <div className="text-[11px] text-slate-400">
              NIST SP 800-61r2 · CERT-In 6-Hour Rule · ISO/IEC 27001
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Clean, Eye-Catching Authentication Form */}
        <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-between space-y-6">
          <div className="space-y-6">
            {/* Top Toggle & Title */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-2 border-b border-slate-100">
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
                  {activeTab === 'signin' ? 'Sign In to Operations' : 'Register New Personnel'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {activeTab === 'signin'
                    ? 'Enter your operational email and authorization password'
                    : 'Create a registered account with designated SOC clearance'}
                </p>
              </div>

              {/* Segmented Control */}
              <div className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200/70 shrink-0 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('signin');
                    setError(null);
                  }}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                    activeTab === 'signin'
                      ? 'bg-white text-slate-800 shadow-2xs border border-slate-200/80'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('register');
                    setError(null);
                  }}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                    activeTab === 'register'
                      ? 'bg-white text-slate-800 shadow-2xs border border-slate-200/80'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Register
                </button>
              </div>
            </div>

            {/* Error Banner */}
            {error && (
              <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1">{error}</div>
              </div>
            )}

            {/* TAB 1: SIGN IN FORM */}
            {activeTab === 'signin' ? (
              <form onSubmit={handleSignIn} className="space-y-4">
                {/* Email Field */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1.5">
                    Official Email / Officer Handle
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. avance@cyberinstincts.soc"
                      required
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-700 bg-white text-slate-900 transition-all font-mono"
                    />
                  </div>
                </div>

                {/* Password Field */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-bold text-slate-800">
                      Master Password
                    </label>
                    <button
                      type="button"
                      onClick={() => setForgotModalOpen(true)}
                      className="text-xs text-blue-700 hover:text-blue-900 hover:underline font-semibold cursor-pointer"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••••••"
                      required
                      className="w-full pl-10 pr-10 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-700 bg-white text-slate-900 transition-all font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-2.5 text-slate-500 hover:text-slate-700 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Remember Me */}
                <div className="flex items-center justify-between text-xs text-slate-700 pt-1">
                  <label className="flex items-center gap-2 cursor-pointer select-none font-medium">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-3.5 h-3.5 rounded border-slate-400 text-blue-700 focus:ring-blue-600"
                    />
                    <span>Keep session active on this workstation</span>
                  </label>

                  <button
                    type="button"
                    onClick={() => {
                      setEmail('avance@cyberinstincts.soc');
                      setPassword('CyberInstincts2026!');
                    }}
                    className="text-xs font-bold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
                  >
                    Autofill Lead Analyst
                  </button>
                </div>

                {/* HIGH-CONTRAST LOGIN BUTTONS */}
                <div className="space-y-2.5 pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3.5 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 active:scale-[0.98] text-white text-sm font-bold shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 border border-blue-800"
                  >
                    <LogIn className="w-4 h-4 text-white" />
                    <span>{loading ? 'Authenticating Analyst Credentials...' : 'Authenticate & Sign In to SOC Console'}</span>
                    <ArrowRight className="w-4 h-4 text-white/80" />
                  </button>

                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => handleSelectPreset(DEMO_USERS[0])}
                    className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 active:scale-[0.98] text-white font-bold text-xs shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-900"
                  >
                    <Sparkles className="w-4 h-4 text-blue-300" />
                    <span>1-Click Instant Demo Login (Lead SOC Analyst)</span>
                  </button>
                </div>
              </form>
            ) : (
              /* TAB 2: REGISTER FORM */
              <form onSubmit={handleRegister} className="space-y-4">
                {/* Full Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Full Name & Title
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Commander Marcus Vance"
                      required
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-600 bg-slate-50/50 text-slate-900 transition-all"
                    />
                  </div>
                </div>

                {/* Email Address */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Official Agency / Corporate Email
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. marcus@cyberinstincts.soc"
                      required
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-600 bg-slate-50/50 text-slate-900 transition-all font-mono"
                    />
                  </div>
                </div>

                {/* Role Designation */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Operational Role Designation
                  </label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-600 bg-slate-50/50 text-slate-900 transition-all"
                  >
                    <option value="Lead Cybersecurity Analyst">Lead Cybersecurity Analyst</option>
                    <option value="Government Liaison Officer (CERT-In)">Government Liaison Officer (CERT-In)</option>
                    <option value="Forensic Cryptographic Investigator">Forensic Cryptographic Investigator</option>
                    <option value="Incident Response Commander">Incident Response Commander</option>
                    <option value="Security Auditor / Cadet">Security Auditor / Cadet</option>
                  </select>
                </div>

                {/* Password */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Master Password
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Minimum 8 characters"
                      required
                      className="w-full pl-10 pr-10 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-600 bg-slate-50/50 text-slate-900 transition-all font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Submit Register */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:scale-[0.99] text-white text-xs font-semibold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>{loading ? 'Creating Credentials...' : 'Register Authorized Analyst'}</span>
                </button>
              </form>
            )}

            {/* Quick Demo Help Banner */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start gap-3 text-xs text-slate-600">
              <Fingerprint className="w-4 h-4 text-cyan-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-900">Capstone Evaluation Mode: </span>
                <span>
                  You can click any of the 4 demo officers on the left to immediately switch roles, inspect SIEM alerts, or upload cryptographic files to MiniVault.
                </span>
              </div>
            </div>
          </div>

          {/* Card Footer */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
            <span>CyberInstincts Security Operations Center v2.4</span>
            <div className="flex items-center gap-3">
              <span className="hover:text-slate-700 cursor-pointer">Security Protocol</span>
              <span>·</span>
              <span className="hover:text-slate-700 cursor-pointer">Terms of Authorization</span>
            </div>
          </div>
        </div>
      </div>

      {/* CCTNS & ICJS OFFICIAL PORTALS SECTION */}
      <div className="bg-white rounded-3xl border border-slate-300 p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded bg-blue-900 text-blue-100 border border-blue-700">
                GOVERNMENT OF INDIA OFFICIAL PORTALS
              </span>
              <span className="text-xs text-slate-600 font-semibold hidden sm:inline">Ministry of Home Affairs & Supreme Court e-Committee</span>
            </div>
            <h3 className="text-xl font-bold text-slate-900 mt-1 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-blue-700" />
              National Law Enforcement & Judicial Network Portals
            </h3>
            <p className="text-xs text-slate-600 mt-0.5 max-w-2xl font-medium">
              Official access links for Crime and Criminal Tracking Network & Systems (CCTNS) and the Inter-Operable Criminal Justice System (ICJS Phase-II).
            </p>
          </div>

          <button
            onClick={() => onNavigateToTab('gov-portal')}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-xs transition-all self-start sm:self-auto cursor-pointer border border-slate-800"
          >
            <span>Open In-App Justice Hub</span>
            <ArrowRight className="w-3.5 h-3.5 text-white/90" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* CCTNS Portal Detail Card */}
          <div className="p-6 rounded-2xl bg-white border-2 border-slate-200 hover:border-slate-300 transition-colors flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-blue-700 text-white flex items-center justify-center font-bold shadow-xs">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-slate-900">
                      CCTNS — Crime & Criminal Tracking Network
                    </h4>
                    <p className="text-xs text-blue-800 font-semibold">
                      digitalpolice.gov.in • cctns.gov.in
                    </p>
                  </div>
                </div>
                <span className="text-xs font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900 border border-blue-200">
                  MHA / NCRB
                </span>
              </div>

              <p className="text-xs text-slate-700 leading-relaxed font-medium">
                National crime and criminal tracking system connecting <strong>16,500+ police stations</strong> across India for pan-India criminal search, biometrics, FIR tracking, and automated cybercrime referral.
              </p>

              <div className="space-y-2 text-xs text-slate-800 font-medium">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0" />
                  <span>Pan-India Core Application Software (CAS) Police Database</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0" />
                  <span>Citizen Services: Cyber Complaints, Verification & NOCs</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0" />
                  <span>Investigating Officer (IO) Digital Case Dossier Repository</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center gap-2.5">
              <a
                href="https://digitalpolice.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold transition-all shadow-xs active:scale-95"
              >
                <span>Launch digitalpolice.gov.in</span>
                <ExternalLink className="w-3.5 h-3.5 text-white/80" />
              </a>
              <a
                href="https://cctns.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-bold transition-all border border-slate-300"
              >
                <span>cctns.gov.in</span>
                <ExternalLink className="w-3.5 h-3.5 text-slate-600" />
              </a>
            </div>
          </div>

          {/* ICJS Portal Detail Card */}
          <div className="p-6 rounded-2xl bg-white border-2 border-slate-200 hover:border-slate-300 transition-colors flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-bold shadow-xs">
                    <Scale className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-slate-900">
                      ICJS — Inter-Operable Criminal Justice System
                    </h4>
                    <p className="text-xs text-emerald-800 font-semibold">
                      icjs.gov.in • ecourts.gov.in
                    </p>
                  </div>
                </div>
                <span className="text-xs font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 border border-emerald-200">
                  Supreme Court
                </span>
              </div>

              <p className="text-xs text-slate-700 leading-relaxed font-medium">
                Seamlessly unifies India’s 5 pillars of justice: <strong>Police (CCTNS), e-Forensics, e-Prosecution, e-Courts, and e-Prisons</strong> on a secure cloud mesh for transparent digital trials.
              </p>

              <div className="space-y-2 text-xs text-slate-800 font-medium">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>Forensic SHA-256 Hash Matching (CFSL / State FSL)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>Sec 65B Indian Evidence Act / BSA 2023 Digital Evidence Filing</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>e-Courts Digital Case Information System (CIS) Docketing</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center gap-2.5">
              <a
                href="https://icjs.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs active:scale-95"
              >
                <span>Launch icjs.gov.in</span>
                <ExternalLink className="w-3.5 h-3.5 text-white/80" />
              </a>
              <a
                href="https://ecourts.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-bold transition-all border border-slate-300"
              >
                <span>ecourts.gov.in</span>
                <ExternalLink className="w-3.5 h-3.5 text-slate-600" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {forgotModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl p-6 max-w-md w-full space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-cyan-600" />
                <h4 className="text-sm font-bold text-slate-900">Account Recovery</h4>
              </div>
              <button
                onClick={() => setForgotModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Enter your registered officer email address to receive an automated authentication reset token.
            </p>

            {forgotSuccess ? (
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Recovery instructions dispatched!</span>
              </div>
            ) : (
              <form onSubmit={handlePasswordReset} className="space-y-3">
                <input
                  type="email"
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="analyst@cyberinstincts.soc"
                  required
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cyan-500 bg-slate-50 font-mono"
                />
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors cursor-pointer"
                >
                  Send Recovery Link
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
